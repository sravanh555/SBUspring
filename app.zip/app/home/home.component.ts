import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';

//import * as CanvasJS from '../assets/canvasjs.min';
//var CanvasJS = require('./canvasjs.min');
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
	products = [];
	//dataSource = this.products;
	dataBar1 = [];
	dataBar2 = [];
	 displayedColumns: string[] = ['segment','riskIdentifiedBy','riskIdentifiedThrough','opensince','program','project','impact','rag','riskID','riskCategory'];
	 

  constructor(private dataService: DataService) { }


  ngOnInit(){
	  this.dataService.sendGetRequest().subscribe((data: any[])=>{
      this.products = data;
	  this.dataSource = this.products;
	//  this.dataBar1 = this.products.map(item => item.id)
	 // this.dataBar2 = this.products.map(item => item.name)
	 // console.log(this.dataBar2);
	  
    })  
  }
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLabels: Label[] = ["apple","banana","pls"];

  
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  
  barChartData: ChartDataSets[] = [
    { data: [10,20,30], label: 'Best Fruits' }
  ];
}
