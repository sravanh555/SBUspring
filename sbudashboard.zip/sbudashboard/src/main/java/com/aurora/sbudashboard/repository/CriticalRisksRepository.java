package com.aurora.sbudashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.model.ProgramMaster;

@Repository
public interface CriticalRisksRepository extends JpaRepository<ProgramMaster, Integer> {

	@Query(value = "SELECT \r\n" + 
			"    Segment_Value AS Segment,\r\n" + 
			"    Program_Name AS Program,\r\n" + 
			"    Project_Name AS Project,\r\n" + 
			"    Aurora_Risk_Seq AS 'RiskID',\r\n" + 
			"    Risk_type AS 'RiskCategory',\r\n" + 
			"    GROUP_CONCAT(DISTINCT Risk_Indicator\r\n" + 
			"        SEPARATOR ',') AS 'RiskIdentifiedThrough',\r\n" + 
			"    Risk_Indicator_Source AS 'RiskIdentifiedBy',\r\n" + 
			"    GROUP_CONCAT(DISTINCT Impact_Type\r\n" + 
			"       SEPARATOR ',') AS Impact,\r\n" + 
			"    rag_status_value AS RAG,\r\n" + 
			"    DATE_FORMAT(Created_Date, '%d-%b-%y') AS 'Opensince'\r\n" + 
			"FROM\r\n" + 
			"    (SELECT \r\n" + 
			"        S.Segment_Value,\r\n" + 
			"            pmr.Program_Name,\r\n" + 
			"            pm.Project_Name,\r\n" + 
			"            rl.Aurora_Risk_Seq,\r\n" + 
			"            cm.risk_type,\r\n" + 
			"            rimm.Risk_Indicator,\r\n" + 
			"            rl.Risk_Indicator_Source,\r\n" + 
			"            im.Impact_Type,\r\n" + 
			"            rs.rag_status_value,\r\n" + 
			"            rl.Created_Date,\r\n" + 
			"            rl.risk_status\r\n" + 
			"    FROM\r\n" + 
			"        program_master pmr\r\n" + 
			"    INNER JOIN project_master pm ON pm.Aurora_Program_Seq_fk = pmr.Aurora_Program_Seq\r\n" + 
			"    INNER JOIN SEGMENT S ON S.Aurora_Segment_Seq = PM.Aurora_Segment_Seq_fk\r\n" + 
			"    INNER JOIN risk_log rl ON pm.Aurora_Project_Seq = rl.Aurora_Project_Seq_fk\r\n" + 
			"    INNER JOIN rag_status rs ON rl.Aurora_RAG_Status_Seq_fk = rs.Aurora_RAG_Status_Seq\r\n" + 
			"    INNER JOIN risk_impact ri ON ri.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq\r\n" + 
			"    INNER JOIN impact_master im ON im.Aurora_Impact_Category_Seq = ri.Aurora_Impact_Category_Seq_pk_fk\r\n" + 
			"    INNER JOIN risk_log_indicator li ON li.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq\r\n" + 
			"    INNER JOIN risk_indicator_master rim ON rim.Aurora_Risk_Indicator_Seq = li.Aurora_Risk_Indicator_Seq_pk_fk\r\n" + 
			"    INNER JOIN risk_category_master cm ON cm.Aurora_Risk_Category_Seq = rim.Aurora_Risk_Category_Seq_fk\r\n" + 
			"    INNER JOIN risk_indicator_master rimm ON rimm.Aurora_Risk_Category_Seq_fk = cm.Aurora_Risk_Category_Seq\r\n" + 
			"    WHERE\r\n" + 
			"        rs.RAG_Status_Value = 'CODE RED' && rl.risk_status = 'A'\r\n" + 
			"            OR rs.RAG_Status_Value = 'AMBER ESCALATE' && rl.Risk_Status = 'A'  ) AS inner_query1\r\n" + 
			"GROUP BY Aurora_Risk_Seq\r\n" + 
			"ORDER BY RAG_Status_Value DESC ,  Created_Date ASC;" , nativeQuery = true)
	List<CriticalRisksDTO> getCriticalRisksDetails();

}