package com.aurora.sbudashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.aurora.sbudashboard.dto.RiskSummaryDTO;
import com.aurora.sbudashboard.model.ProgramMaster;

@Repository
public interface RiskSummaryRepository extends JpaRepository<ProgramMaster, Integer> {

	@Query(value = "SELECT pm.program_name As Program, rcm.Risk_Type As Category, count(Risk_Type) As Risk FROM aurora.program_master pm INNER JOIN aurora.project_master p ON p.Aurora_Program_Seq_fk = pm.Aurora_Program_Seq INNER JOIN aurora.Risk_Log rl INNER JOIN aurora.rag_status rs on rs.Aurora_RAG_Status_Seq = rl.Aurora_RAG_Status_Seq_fk INNER JOIN aurora.risk_log_indicator rli on rli.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq INNER JOIN aurora.risk_indicator_master rim on rim.Aurora_Risk_Indicator_Seq = rli.Aurora_Risk_Indicator_Seq_pk_fk INNER JOIN aurora.Risk_Category_Master rcm ON rim.Aurora_Risk_Category_Seq_fk = rcm.Aurora_Risk_Category_Seq WHERE rl.Aurora_Project_Seq_fk = p.Aurora_Project_Seq && p.Aurora_Program_Seq_fk = pm.Aurora_Program_Seq && rim.Aurora_Risk_Category_Seq_fk = rcm.Aurora_Risk_Category_Seq group by Program_Name,risk_type order by Program_Name desc;", nativeQuery = true)
	List<RiskSummaryDTO> getRiskSummaryDetails();

}
