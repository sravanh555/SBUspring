package com.aurora.sbudashboard.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="segment")
public class Segment {
	@Id
	@Column(name = "Aurora_Segment_Seq",columnDefinition = "int",nullable = false )
	private int auroraSegmentSeq;
	


	@Column(name = "Segment_Value",columnDefinition = "varchar(45)",nullable = false )
	private String segmentValue;

	
	@OneToMany(mappedBy = "segment")
	private List<ProjectMaster> projects;
	
	public void setProjects(List<ProjectMaster> projects) {
		this.projects = projects;
	}

	public List<ProjectMaster> getProjects() {
		return projects;
	}

	public int getAuroraSegmentSeq() {
		return auroraSegmentSeq;
	}


	public void setAuroraSegmentSeq(int auroraSegmentSeq) {
		this.auroraSegmentSeq = auroraSegmentSeq;
	}


	public String getSegmentValue() {
		return segmentValue;
	}

	public void setSegmentValue(String segmentValue) {
		this.segmentValue = segmentValue;
	}


	@Override
	public String toString() {
		return "Segment [auroraSegmentSeq=" + auroraSegmentSeq + ", segmentValue=" + segmentValue + ", projects="
				+ projects + "]";
	}
}

